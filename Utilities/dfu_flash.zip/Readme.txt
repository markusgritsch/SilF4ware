* Copy _flash.bat and HEX2DFU.exe to
C:\Program Files (x86)\STMicroelectronics\Software\DfuSe v3.0.6\Bin

* Add the following 'After Build' command to Keil uVision
"C:\Program Files (x86)\STMicroelectronics\Software\DfuSe v3.0.6\Bin\_flash.bat" "#H"
